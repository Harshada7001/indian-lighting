   <nav id="sidebar" class="active">
            <div class="sidebar-header">
                <!--IL-->
                <img src="../logo/logo.png" alt="bootraper logo" class="app-logo" width="50">ILA
            </div>
            <ul class="list-unstyled components text-secondary">
                <li>
                    <a href="#"><i class="fas fa-home"></i>Dashboard</a>
                </li>
                <li>
                    <a href="add_category.php"><i class="fas fa-file-alt"></i>Add  Categories</a>
                </li>
                <li>
                    <a href="add_products.php"><i class="fas fa-table"></i>Add Products</a>
                </li>
                <li>
                    <a href="add_sppliers.php"><i class="fas fa-chart-bar"></i>Add Suppliers</a>
                </li>
                <li>
                    <a href="#"><i class="fas fa-icons"></i>Add News</a>
                </li>
                <li>
                    <a href="#uielementsmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down"><i class="fas fa-layer-group"></i>View Records</a>
                    <ul class="collapse list-unstyled" id="uielementsmenu">
                        <li>
                            <a href="viewcategory.php"><i class="fas fa-angle-right"></i>View Categories</a>
                        </li>
                        <li>
                            <a href="viewproducts.php"><i class="fas fa-angle-right"></i>View Products</a>
                        </li>
                        <li>
                            <a href="viewsuplliers.php"><i class="fas fa-angle-right"></i>View Suppliers</a>
                        </li>
<!--                        <li>
                            <a href="ui-alerts.html"><i class="fas fa-angle-right"></i>Alerts</a>
                        </li>
                        <li>
                            <a href="ui-tabs.html"><i class="fas fa-angle-right"></i>Tabs</a>
                        </li>
                        <li>
                            <a href="ui-date-time-picker.html"><i class="fas fa-angle-right"></i>Date & Time Picker</a>
                        </li>-->
                    </ul>
                </li>
                <li>
<!--                    <a href="#authmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down"><i class="fas fa-user-shield"></i>Authentication</a>
                    <ul class="collapse list-unstyled" id="authmenu">
                        <li>
                            <a href="login.html"><i class="fas fa-lock"></i>Login</a>
                        </li>
                        <li>
                            <a href="signup.html"><i class="fas fa-user-plus"></i>Signup</a>
                        </li>
                        <li>
                            <a href="forgot-password.html"><i class="fas fa-user-lock"></i>Forgot password</a>
                        </li>
                    </ul>-->
                </li>
               
            </ul>
        </nav>